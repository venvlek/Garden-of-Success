<?php
require_once __DIR__ . '/../db.php';
session_destroy(); header('Content-Type: application/json'); echo json_encode(['ok'=>true]);
?>